
try:
    result = '5' + 5  # Intentando sumar un string y un entero
except TypeError as e:
    print(f"Error: {e}")
